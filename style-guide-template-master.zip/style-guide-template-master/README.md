Style Guide Template
=========

A customizable Style Guide template, to gather design guidelines and share them with colleagues and clients.

[Article on CodyHouse](http://codyhouse.co/gem/css-style-guide-template/)

[Demo](http://codyhouse.co/demo/style-guide-template/index.html)

Icons by [Petras Nargela](https://dribbble.com/petrasnargela) available for free download on [Freebiesbug](http://freebiesbug.com/psd-freebies/80-stroke-icons-psd-ai-webfont/)
 
[Terms](http://codyhouse.co/terms/)
